using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraScript : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject camera1,camera2;
   

    // Update is called once per frame
    int num;

    void Start(){
        camera1.SetActive(true);
        camera2.SetActive(false);
        num = 0;
    }
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Space)){
            num++;
            if(num % 2 !=0){
                 camera1.SetActive(false);
                 camera2.SetActive(true);

            }else{
                 camera1.SetActive(true);
                 camera2.SetActive(false);

            }  
        }
    }
}
