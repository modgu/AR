using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class Cube : MonoBehaviour
{
    // Start is called before the first frame update


    public string [] textures = {"wood","galaxy","grass","iron","lava","sand","sea","gold","moon","diamond"};
    

    // Update is called once per frame
    void Update()
    {

        if (Input.GetMouseButtonDown(0)){

        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;

        if (Physics.Raycast(ray, out hit))
        {  

            if (hit.transform.name == "Cube")
            {
                int rand = Random.Range(0,10);
                byte[] bytes = File.ReadAllBytes("./Assets/textures/"+textures[rand]+".jpg");
                Texture2D texture = new Texture2D(100, 100);
                texture.filterMode = FilterMode.Trilinear;
                texture.LoadImage(bytes);  
                MeshRenderer meshRenderer = GetComponent<MeshRenderer>();
                meshRenderer.material.SetTexture("_MainTex", texture);
            }
        }
    }
        
    }
}
